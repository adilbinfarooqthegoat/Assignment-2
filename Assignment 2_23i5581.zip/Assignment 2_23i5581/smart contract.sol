// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

contract SimpleStorage {
    string private message;
    uint256 private counter;

    event MessageUpdated(address indexed by, string newMessage);
    event CounterIncremented(address indexed by, uint256 newCount);

    constructor() {
        message = "Hello!";
    }

    function setMessage(string memory _newMessage) public {
        message = _newMessage;
        emit MessageUpdated(msg.sender, _newMessage);
    }

    function getMessage() public view returns (string memory) {
        return message;
    }

    function incrementCounter() public {
        counter += 1;
        emit CounterIncremented(msg.sender, counter);
    }

    function getCounter() public view returns (uint256) {
        return counter;
    }
}